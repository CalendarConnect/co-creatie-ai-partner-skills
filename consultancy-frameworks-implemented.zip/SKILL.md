---
name: consultancy-frameworks-implemented
description: Activate strategic intelligence with 100+ business frameworks on command.
metadata:
  version: 1.0.0
  dependencies: none
---

# Consultancy Frameworks Implemented

This skill provides strategic intelligence on demand. By typing `/fw`, Claude activates a vast mental library of over 100 business frameworks, methodologies, and founder philosophies to select and apply the right framework(s) to your specific business challenge, context, and phase. It’s as if an experienced founder-operator joined your call and said, “Here’s the lens you need, and here’s how to use it right now.”

## Quick Start

1. Type `/fw` followed by your business challenge or context.
2. Claude will analyze your request and determine the nature of the challenge, business phase, desired outcome, and audience.
3. The AI selects and applies the most relevant frameworks, providing a structured response with action steps and expected outcomes.

## When to Use This Skill

- When you need strategic direction or business focus.
- When execution plans exist but progress stalls.
- When faced with product-market fit challenges or innovation needs.
- When experiencing growth plateaus or sales conversion issues.
- When dealing with team dynamics, personal effectiveness, or decision-making under uncertainty.

## How It Works

The skill operates through three main steps:
- **Context Analysis**: Analyzes the user's request to understand the challenge, business phase, desired outcome, and audience.
- **Framework Selection Logic**: Chooses the best-fit frameworks based on context-matching keywords, problem structure, and intent.
- **Framework Application**: Provides a structured response with a primary framework, alternatives, founder wisdom, and next steps.

## Usage

To use this skill, type `/fw` followed by your query. Claude will deliver a tailored analysis using the most suitable framework(s). For example:
- "Which direction should we take?" will trigger strategy frameworks.
- "Our product isn’t sticking." will prompt product frameworks.
- "I feel stuck or distracted." will lead to personal frameworks.

## Example Prompts

> "/fw Growth is flat."

> "/fw How would Elon Musk handle this?"

## Best Practices

1. Clearly describe your business challenge or context when using `/fw`.
2. Review the suggested frameworks and action steps to ensure they align with your specific needs and goals.
3. Consider the provided founder wisdom to gain new perspectives or insights.

## Notes

This skill is not intended for mere information retrieval; it focuses on applying contextual frameworks to real-world business situations. Adapt the recommendations to fit your unique context and constraints.

## Behavior Guidelines

✅ **DO:**
- Use this skill for strategic planning and problem-solving.
- Apply the recommended frameworks to improve business outcomes.

❌ **DON'T:**
- Use the skill for simple information gathering without context.
- Rely solely on the output without considering your specific situation.

With this skill, you gain access to a comprehensive strategic intelligence system, enabling precise application of business frameworks and founder wisdom to your current challenges.

## FULL FRAMEWORK INDEX — ALL FRAMEWORKS IMPLEMENTED BY /fw

1. STRATEGY FRAMEWORKS

Used when direction, differentiation, or focus are unclear.

OGSM (Objectives, Goals, Strategies, Measures)

Blue Ocean Strategy

Playing to Win (Lafley & Martin)

Good Strategy Bad Strategy (Rumelt)

McKinsey 7S Framework

BCG Matrix (Growth Share Matrix)

Ansoff Matrix (Product-Market Expansion Grid)

Porter’s Five Forces

VRIO Framework (Value, Rarity, Imitability, Organization)

Value Chain Analysis

Business Model Canvas (Osterwalder)

Lean Canvas (Maurya)

Jobs-to-be-Done (Strategic level)

2. EXECUTION & OPERATIONS FRAMEWORKS

Used when plans exist but progress stalls.

OKRs (Objectives & Key Results)

Balanced Scorecard (Kaplan & Norton)

Theory of Constraints (Goldratt)

Lean Thinking (Womack & Jones)

Six Sigma (DMAIC)

Agile / Scrum

Kanban Method

GTD (Getting Things Done – Allen)

Eisenhower Matrix (Urgent vs Important)

RACI Matrix (Responsible, Accountable, Consulted, Informed)

Critical Path / Gantt Planning

3. PRODUCT & INNOVATION FRAMEWORKS

Used for discovery, validation, and product-market fit.

Design Thinking (Empathize → Define → Ideate → Prototype → Test)

Lean Startup (Build → Measure → Learn)

Jobs to Be Done (JTBD)

Crossing the Chasm (Moore)

Technology Adoption Lifecycle

Innovation Ambition Matrix (Core, Adjacent, Transformational)

Three Horizons of Innovation (McKinsey)

Disruptive Innovation (Christensen)

First Principles Thinking

4. GROWTH & MARKETING FRAMEWORKS

Used to scale and diagnose growth issues.

Pirate Metrics (AARRR – Acquisition, Activation, Retention, Revenue, Referral)

Growth Loops

North Star Metric

CAC & LTV Economics

Hooked Model (Eyal)

Viral Coefficient

SaaS Metrics 2.0 (OpenView)

ICE/RICE Prioritization

Predictable Revenue Model (Ross)

Flywheel Growth Model

5. SALES & PERSUASION FRAMEWORKS

Used to increase conversion and improve sales methodology.

The Challenger Sale (Teach, Tailor, Take Control)

SPIN Selling (Situation, Problem, Implication, Need-Payoff)

MEDDIC / MEDDPICC Qualification Framework

Cialdini’s 6 Principles of Influence

Solution Selling

Value Selling Framework

Sandler Selling System

Miller Heiman Strategic Selling

NEPQ (Neuro-Emotional Persuasion Questioning)

6. LEADERSHIP & CULTURE FRAMEWORKS

Used when team dynamics or culture become a constraint.

Radical Candor (Kim Scott)

Five Dysfunctions of a Team (Lencioni)

Psychological Safety (Amy Edmondson)

High Output Management (Andy Grove)

Situational Leadership (Hersey & Blanchard)

Servant Leadership

Tuckman’s Stages of Team Development

Emotional Intelligence (EQ – Goleman)

The Hard Thing About Hard Things (Horowitz)

First Team Mindset (Lencioni)

7. PERSONAL EFFECTIVENESS FRAMEWORKS

Used for founder performance, focus, and sustainability.

Deep Work (Cal Newport)

Atomic Habits (James Clear)

The One Thing (Gary Keller)

80/20 Principle (Pareto)

7 Habits of Highly Effective People (Covey)

4-Hour Workweek Principles (Ferriss)

Time Blocking / Calendar Discipline

Energy Management Model

Eisenhower Prioritization

Flow State Triggers (Kotler)

8. DECISION MAKING & PROBLEM SOLVING FRAMEWORKS

Used for strategic decisions, risk, and clarity under uncertainty.

Second-Order Thinking

Inversion Thinking (Charlie Munger)

Pre-Mortem Analysis (Klein)

Decision Trees / Expected Value Analysis

Mental Models (Farnam Street / Munger)

Cost-Benefit Analysis

SWOT Analysis

PEST / PESTLE Environmental Scan

Scenario Planning

Red Team / Blue Team Approach

OODA Loop (Observe, Orient, Decide, Act)

9. FOUNDER WISDOM & ICONIC METHODOLOGIES

Used for perspective shifts, principles, and long-term thinking.

Mark Zuckerberg (Meta): Move Fast, Long-Term Thinking
“The biggest risk is not taking any risk.”

Reed Hastings (Netflix): Freedom & Responsibility, Radical Transparency
“Adequate performance gets a generous severance.”

Brian Chesky (Airbnb): 11-Star Experience, Founder Mode
“Build something 100 people love, not 1 million people like.”

Jeff Bezos (Amazon): Customer Obsession, Day 1 Mentality
“Your margin is my opportunity.”

Elon Musk (Tesla/SpaceX): First Principles, 10x Thinking
“Reason from first principles, not analogy.”

Sam Altman (OpenAI): Compounding Focus, Curiosity-Driven Work
“Work on what compounds.”

Patrick Collison (Stripe): Systems Thinking & Ambitious Pragmatism

Daniel Ek (Spotify): Autonomy & Alignment in Creative Systems

Jensen Huang (NVIDIA): Relentless Innovation and Strategic Patience

Marc Benioff (Salesforce): Platform Thinking & Stakeholder Capitalism