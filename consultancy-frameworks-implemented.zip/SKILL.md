---
name: consultancy-frameworks-implemented
description: Framework & Founder Wisdom Protocol for strategic intelligence on demand.
metadata:
  version: 1.0.0
  dependencies: "none"
---

# Consultancy Frameworks Implemented

This skill empowers users with the Framework & Founder Wisdom Protocol, enabling strategic intelligence on demand. By simply typing /fw, users access a vast library of 100+ business frameworks and founder philosophies, intelligently selecting and applying the right framework to their specific challenge and context.

## Quick Start

1. Type `/fw` followed by your specific business challenge or question.
2. The AI analyzes your request, determining the challenge type, business phase, desired outcome, and audience.
3. It selects and recommends the most relevant frameworks, providing a structured application plan.

## When to Use This Skill

- When you need strategic direction or clarity
- During execution stalls or growth plateaus
- For product-market fit challenges or sales hurdles
- When facing leadership or team alignment issues
- For personal productivity or decision-making dilemmas

## How It Works

### Step 1 — Context Analysis
The AI scans the request to identify the nature of the challenge, business phase, desired outcome, and audience focus.

### Step 2 — Framework Selection Logic
Using context-matching, the AI selects a primary framework and 1-2 alternatives, explaining their relevance to the user's scenario.

### Step 3 — Framework Application
The AI provides a structured response with a concise framework definition, reasons for its fit, action steps, real-world examples, and expected outcomes.

## Behavior Guidelines

✅ **DO:**
- Use the skill for strategic insights and operational guidance.
- Apply the recommended frameworks for practical challenges.

❌ **DON'T:**
- Use the skill for unrelated information retrieval.
- Blindly adopt frameworks without considering context.

## Usage

Type `/fw` followed by your challenge, such as "Growth is flat" or "Which direction should we take?" The skill will return a detailed framework application tailored to your situation.

## Example Prompts

> "/fw Which direction should we take?"

> "/fw Our product isn't sticking."

## Files

- No additional files are required for this skill.

## Notes

This skill uses a sophisticated algorithm to match user queries with the most relevant frameworks, providing not just recommendations but actionable implementation plans.

## Best Practices

1. Clearly define your challenge when invoking the skill.
2. Consider the business phase and desired outcome for accurate framework application.
3. Review and adapt the recommended action steps to fit your unique context.

##FULL FRAMEWORK INDEX — ALL FRAMEWORKS IMPLEMENTED BY /fw
1. STRATEGY FRAMEWORKS

Used when direction, differentiation, or focus are unclear.

OGSM (Objectives, Goals, Strategies, Measures)

Blue Ocean Strategy

Playing to Win (Lafley & Martin)

Good Strategy Bad Strategy (Rumelt)

McKinsey 7S Framework

BCG Matrix (Growth Share Matrix)

Ansoff Matrix (Product-Market Expansion Grid)

Porter’s Five Forces

VRIO Framework (Value, Rarity, Imitability, Organization)

Value Chain Analysis

Business Model Canvas (Osterwalder)

Lean Canvas (Maurya)

Jobs-to-be-Done (Strategic level)

## 2. EXECUTION & OPERATIONS FRAMEWORKS

Used when plans exist but progress stalls.

OKRs (Objectives & Key Results)

Balanced Scorecard (Kaplan & Norton)

Theory of Constraints (Goldratt)

Lean Thinking (Womack & Jones)

Six Sigma (DMAIC)

Agile / Scrum

Kanban Method

GTD (Getting Things Done – Allen)

Eisenhower Matrix (Urgent vs Important)

RACI Matrix (Responsible, Accountable, Consulted, Informed)

Critical Path / Gantt Planning

## 3. PRODUCT & INNOVATION FRAMEWORKS

Used for discovery, validation, and product-market fit.

Design Thinking (Empathize → Define → Ideate → Prototype → Test)

Lean Startup (Build → Measure → Learn)

Jobs to Be Done (JTBD)

Crossing the Chasm (Moore)

Technology Adoption Lifecycle

Innovation Ambition Matrix (Core, Adjacent, Transformational)

Three Horizons of Innovation (McKinsey)

Disruptive Innovation (Christensen)

First Principles Thinking

## 4. GROWTH & MARKETING FRAMEWORKS

Used to scale and diagnose growth issues.

Pirate Metrics (AARRR – Acquisition, Activation, Retention, Revenue, Referral)

Growth Loops

North Star Metric

CAC & LTV Economics

Hooked Model (Eyal)

Viral Coefficient

SaaS Metrics 2.0 (OpenView)

ICE/RICE Prioritization

Predictable Revenue Model (Ross)

Flywheel Growth Model

## 5. SALES & PERSUASION FRAMEWORKS

Used to increase conversion and improve sales methodology.

The Challenger Sale (Teach, Tailor, Take Control)

SPIN Selling (Situation, Problem, Implication, Need-Payoff)

MEDDIC / MEDDPICC Qualification Framework

Cialdini’s 6 Principles of Influence

Solution Selling

Value Selling Framework

Sandler Selling System

Miller Heiman Strategic Selling

NEPQ (Neuro-Emotional Persuasion Questioning)

## 6. LEADERSHIP & CULTURE FRAMEWORKS

Used when team dynamics or culture become a constraint.

Radical Candor (Kim Scott)

Five Dysfunctions of a Team (Lencioni)

Psychological Safety (Amy Edmondson)

High Output Management (Andy Grove)

Situational Leadership (Hersey & Blanchard)

Servant Leadership

Tuckman’s Stages of Team Development

Emotional Intelligence (EQ – Goleman)

The Hard Thing About Hard Things (Horowitz)

First Team Mindset (Lencioni)

## 7. PERSONAL EFFECTIVENESS FRAMEWORKS

Used for founder performance, focus, and sustainability.

Deep Work (Cal Newport)

Atomic Habits (James Clear)

The One Thing (Gary Keller)

80/20 Principle (Pareto)

7 Habits of Highly Effective People (Covey)

4-Hour Workweek Principles (Ferriss)

Time Blocking / Calendar Discipline

Energy Management Model

Eisenhower Prioritization

Flow State Triggers (Kotler)

## 8. DECISION MAKING & PROBLEM SOLVING FRAMEWORKS

Used for strategic decisions, risk, and clarity under uncertainty.

Second-Order Thinking

Inversion Thinking (Charlie Munger)

Pre-Mortem Analysis (Klein)

Decision Trees / Expected Value Analysis

Mental Models (Farnam Street / Munger)

Cost-Benefit Analysis

SWOT Analysis

PEST / PESTLE Environmental Scan

Scenario Planning

Red Team / Blue Team Approach

OODA Loop (Observe, Orient, Decide, Act)

## 9. FOUNDER WISDOM & ICONIC METHODOLOGIES

Used for perspective shifts, principles, and long-term thinking.

Mark Zuckerberg (Meta): Move Fast, Long-Term Thinking
“The biggest risk is not taking any risk.”

Reed Hastings (Netflix): Freedom & Responsibility, Radical Transparency
“Adequate performance gets a generous severance.”

Brian Chesky (Airbnb): 11-Star Experience, Founder Mode
“Build something 100 people love, not 1 million people like.”

Jeff Bezos (Amazon): Customer Obsession, Day 1 Mentality
“Your margin is my opportunity.”

Elon Musk (Tesla/SpaceX): First Principles, 10x Thinking
“Reason from first principles, not analogy.”

Sam Altman (OpenAI): Compounding Focus, Curiosity-Driven Work
“Work on what compounds.”

Patrick Collison (Stripe): Systems Thinking & Ambitious Pragmatism

Daniel Ek (Spotify): Autonomy & Alignment in Creative Systems

Jensen Huang (NVIDIA): Relentless Innovation and Strategic Patience

Marc Benioff (Salesforce): Platform Thinking & Stakeholder Capitalism

## FRAMEWORK SELECTION & CONTEXT-MATCHING ALGORITHM
Situation	Primary Framework	When to Use
Direction unclear	OGSM, Playing to Win, Blue Ocean	Need focus or differentiation
Competing on price	Blue Ocean, Value Chain	Must escape red ocean competition
Overloaded strategy	Playing to Win, Good Strategy Bad Strategy	Too many initiatives
Execution misalignment	OKRs, Balanced Scorecard, Theory of Constraints	Hard work ≠ results
Product underused	Jobs to Be Done, Design Thinking	Misunderstood customer motivation
Growth plateau	AARRR, Growth Loops, North Star Metric	Funnel or retention issues
Deals not closing	Challenger Sale, SPIN, MEDDIC	Need stronger discovery and insight
Team conflict	Five Dysfunctions, Psychological Safety	Trust and accountability gaps
Personal overload	Deep Work, The One Thing, Atomic Habits	Focus and consistency needed
Risky decision	Pre-Mortem, Second-Order Thinking, Inversion	High stakes, uncertain outcomes
Inspiration	Founder Wisdom	Need new lens or philosophy
STEP 4 — OUTPUT GENERATION

After selection, /fw delivers:

Applied analysis of the situation using the framework logic.

Action plan with concrete implementation steps.

Expected results or indicators of success.

Alternative frameworks for optional comparison.

Founder quote or principle reinforcing the mindset.

## STEP 5 — ETHICAL FRAMEWORK USE

Frameworks are maps, not territories.

Adapt, don’t adopt blindly.

Always recheck assumptions against the Constraint Spine:

Authenticity — does it fit who you are?

Integrity — are you using it for the right reasons?

Impact — does it deliver real value?

OUTPUT SPECIFICATION

When /fw is used, the AI returns:

Framework selection and reasoning

Tailored analysis and implementation plan
