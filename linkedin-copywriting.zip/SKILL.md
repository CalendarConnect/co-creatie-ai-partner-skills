---
name: linkedin-copywriting
description: Framework for creating effective LinkedIn content using a 6-step growth marketing workflow
metadata:
  version: 1.0.0
  dependencies: none
---

# LinkedIn Copywriting

This skill provides a comprehensive framework for crafting effective LinkedIn content tailored to different stages of the customer journey. Leveraging growth marketing principles, it enables the creation of authentic, high-converting posts by combining brand DNA with proven content frameworks.

## Quick Start

1. Type `/l` to activate the LinkedIn Copywriting skill.
2. Select the type of LinkedIn post you want to create (TOFU, MOFU, BOFU).
3. Follow the 6-step framework to develop your post:
   - Content Type Exploration
   - Hook Development Process
   - Narrative Development
   - Content Optimization for LinkedIn
   - Authenticity & Values Check
   - Final Post Assembly

## When to Use This Skill

- When crafting LinkedIn content for brand growth and lead generation.
- When needing a structured approach to LinkedIn post creation.
- When aiming to align content with business values and audience needs.

## How It Works

This skill guides users through a 6-step workflow to generate LinkedIn posts:

1. **Content Type Exploration**: Identify the type of content (TOFU, MOFU, BOFU) suitable for your audience's stage in the customer journey.
2. **Hook Development Process**: Create attention-grabbing hooks using various styles suitable for each content type.
3. **Narrative Development**: Build the core story using templates that align with client profiles and business values.
4. **Content Optimization for LinkedIn**: Optimize content for readability, engagement, and cultural fit.
5. **Authenticity & Values Check**: Ensure the post aligns with brand tone and values before publishing.
6. **Final Post Assembly**: Structure the final LinkedIn post with optimized components and industry-relevant hashtags.

## Usage

Use the skill by typing `/l` to start the LinkedIn Copywriting process. Follow the prompts to explore content types, develop hooks, and construct narratives. Optimize and verify authenticity before publishing.

## Example Prompts

> "What type of LinkedIn post would you like to create today? I’ll help you choose the right approach based on where your ideal customers are in their journey toward your solution."

> "Let’s create an opening that immediately grabs attention. Here are hook styles that work well:"

## Files

- `linkedin-framework.txt` - Contains the full 6-step workflow and content templates.

## Notes

This skill is designed to help users create LinkedIn content that is strategic, emotionally intelligent, and aligned with genuine business values. It is suitable for both AI systems and human creators.

## Best Practices

1. Always tailor content to the target audience's stage in the customer journey.
2. Use data and insights to craft compelling hooks and narratives.
3. Regularly review and adjust content based on engagement metrics and audience feedback.