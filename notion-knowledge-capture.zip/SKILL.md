---
name: notion-knowledge-capture
description: Transforms conversations and discussions into structured documentation pages in Notion.
metadata:
  version: 1.0.0
  dependencies: "Notion:notion-search, Notion:notion-create-pages, Notion:notion-update-page"
---

# Notion Knowledge Capture

Transforms conversations, discussions, and insights into structured documentation in your Notion workspace. This skill captures knowledge from chat context, formats it appropriately, and saves it to the right location with proper organization and linking.

## Quick Start

When asked to save information to Notion:

1. **Extract content**: Identify key information from conversation context.
2. **Structure information**: Organize into appropriate documentation format.
3. **Determine location**: Use `Notion:notion-search` to find the appropriate wiki page or database.
4. **Create page**: Use `Notion:notion-create-pages` to save content.
5. **Make discoverable**: Link from relevant hub pages, add to databases, or update wiki navigation for easy discovery.

## When to Use This Skill

- When a conversation includes important insights or decisions that need documentation.
- When creating structured documentation from discussions for future reference.
- When updating or creating new pages in your Notion workspace for knowledge sharing.

## How It Works

This skill processes input by extracting key points and organizing them into a structured format, suitable for various documentation types like how-to guides, FAQs, decision records, etc. It determines the best location within your Notion workspace to store the information, ensuring it is linked appropriately for easy discovery.

## Usage

To use this skill, follow these steps:
- Engage in a conversation that requires documentation.
- Use this skill to extract insights and structure them appropriately.
- Save the structured content to Notion using provided functions.
- Ensure the content is linked and tagged for discoverability.

## Example Prompts

> "Can you save the key points from this meeting to Notion?"

> "Create a how-to guide from our discussion on deploying to production."

## Files (if applicable)

- No additional files required.

## Notes

Ensure that the Notion API integration is set up correctly to allow communication between Claude and your Notion workspace.

## Best Practices

1. Capture knowledge promptly while the context is fresh.
2. Use templates to maintain consistency across similar content types.
3. Extensively link related knowledge to enhance discoverability.
4. Write with searchable titles and tags to aid in easy retrieval.
5. Include context and examples to facilitate understanding.
6. Regularly review and update documentation to keep it current.
7. Seek feedback to ensure the documentation meets user needs.