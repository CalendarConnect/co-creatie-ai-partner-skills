---
name: auto-website-to-notion-crm-update
description: Automate lead prospecting by analyzing websites and updating Notion CRM.
metadata:
  version: 1.0.0
  dependencies: Notion MCP, website analysis tools
---

# Auto Website to Notion CRM Update

The Auto Website to Notion CRM Update skill automates the lead prospecting process by analyzing a company's website, comparing it to your Ideal Customer Profile (ICP), and updating your Notion CRM with a detailed analysis summary. This skill streamlines lead research into a data-driven, automated workflow.

## Quick Start

1. Activate the skill by typing `/p`.
2. Provide the website URL when prompted.
3. Confirm ICP match and CRM update.
4. View the updated analysis in Notion CRM.

## When to Use This Skill

- You need to quickly assess whether a lead fits your target audience.
- You want to automate the process of updating your CRM with prospecting data.
- You are performing multiple prospect analyses and want to streamline the workflow.

## How It Works

The skill performs a comprehensive analysis of a prospect's website, retrieves context from your Notion CRM, and determines the lead's fit with your ICP. It then generates a summary analysis and updates the Notion CRM if a match is found.

- **Input**: Website URL, optionally company name.
- **Processing**: Website intelligence gathering, ICP fit analysis.
- **Output**: CRM update with analysis summary if the lead fits your ICP.

## Behavior Guidelines

✅ **DO:**
- Use publicly available website data.
- Update the CRM only with confirmed matches.

❌ **DON'T:**
- Scrape behind paywalls or restricted areas.
- Store personal data outside of the CRM.

## Usage

To use this skill, trigger it with the `/p` command and follow the prompts to provide the website URL. Confirm the ICP match and choose to update the CRM with the analysis summary.

## Example Prompts

> "Please share the website URL of the prospect you’d like me to analyze."

> "This prospect appears to fit your ICP. Would you like me to update the Notion CRM ‘analysis’ field with this summary?"

## Files

- `integration.py` - Handles MCP integration for Notion updates.
- `analysis.py` - Performs website analysis and ICP comparison.

## Notes

- This skill respects data privacy and compliance regulations.
- Ensure your Notion CRM is configured with MCP integration for optimal use.

## Best Practices

1. Regularly update your ICP to ensure accurate fit analyses.
2. Use the `/p outreach` variant to generate follow-up content.
3. Confirm all CRM updates to prevent duplications.