---
name: neuromarketing-copywriting
description: Enhance copywriting with neuromarketing principles for emotional and rational appeal
metadata:
  version: 1.0.0
  dependencies: none
---

# Neuromarketing Copywriting

This skill leverages neuromarketing principles to enhance copywriting by appealing to both the intuitive and rational aspects of the brain. Based on the works of Daniel Kahneman, Robert Cialdini, and Martin van Kranenburg, this skill helps create content that is clear, emotionally intelligent, and persuasive.

## Quick Start

1. Activate neuromarketing mode by typing `/n` or asking directly for help with neuromarketing copywriting.
2. Follow the framework to craft content that engages System 1 (emotion) and System 2 (logic).

## When to Use This Skill

- When crafting marketing copy that needs to connect emotionally and rationally with the audience
- To enhance engagement and persuasion in advertisements and promotional materials
- When aiming to balance emotional appeal with logical justification in writing

## How It Works

The neuromarketing copywriting skill guides the creation of content by:
- Activating System 1 (intuitive brain) with emotional and recognizable cues
- Supporting the intuitive appeal with System 2 (rational brain) logic and evidence
- Using principles of social proof, authority, scarcity, and reciprocity to enhance persuasion

## Behavior Guidelines

✅ **DO:**
- Focus on emotional engagement first
- Use simple, familiar language
- Provide clear, logical explanations after emotional appeal

❌ **DON'T:**
- Overwhelm with data before establishing emotional connection
- Use complex jargon without clarification
- Manipulate or deceive; maintain ethical standards

## Usage

To use this skill, activate neuromarketing mode and follow the structured framework:
- [HOOK] Start with a pattern interrupt
- [RECOGNITION] Identify the reader's situation
- [EMOTION] Trigger a motivator like greed or fear
- [PROMISE] Offer a transformative benefit
- [SOCIAL PROOF] Provide testimonials or cases
- [AUTHORITY] Establish expertise
- [SCARCITY] Create urgency
- [RECIPROCITY] Offer value first
- [LIKING] Communicate warmth and authenticity
- [COMMITMENT] Encourage a small initial step
- [UNITY] Relate to shared values

Then transition to System 2:
- [PROOF] Present data and results
- [LOGIC] Explain methods
- [DETAILS] Outline specifics like price and deliverables
- [CTA] Include a clear call to action

## Example Prompts

> "Help me with neuromarketing copywriting."

> "Apply neuromarketing principles to this ad."

> "Write for the brain using emotional and logical appeal."

## Notes

This skill is designed to ethically enhance marketing materials by understanding and applying psychological principles to copywriting. It emphasizes empathy and transparency in all communications.

## Best Practices

1. Begin with an emotional hook to capture attention quickly.
2. Transition smoothly from emotional appeal to logical rationale.
3. Ensure all claims are supported by verifiable data and genuine proof.