---
name: geo-copywriting
description: GEO Blog Article Optimization Skill using intent mapping and SEO principles
metadata:
  version: 1.0.0
  dependencies: none
---

# GEO Copywriting

The GEO Copywriting skill transforms any draft or idea into a GEO-aligned blog article using intent mapping and growth-focused SEO principles. This ensures every article ranks well and converts effectively by addressing what readers truly seek, rather than just what they type.

## Quick Start

1. Type `/s` followed by your draft or idea.
2. The AI analyzes the content and optimizes it into a GEO-aligned blog article.
3. Receive a fully optimized article with intent matching, funnel stage alignment, and SEO enhancements.

## When to Use This Skill

- When you need to optimize a blog article for search engines and conversion.
- When you want to ensure content aligns with user intent and journey stage.
- When you require a structured and high-performing content piece.

## How It Works

The GEO Copywriting skill operates through a 12-step optimization workflow:
- Detects reader intent and aligns with the funnel stage.
- Defines the article goal based on audience persona.
- Maps keywords to intent, avoiding keyword stuffing.
- Chooses prompt patterns that fit the detected intent.
- Structures articles for GEO readability and engagement.
- Adopts persona-based drafting to enhance relevance.
- Integrates objection handling and reassurances.
- Crafts conversion-specific CTAs.
- Ensures compliance with data accuracy and brand guidelines.
- Enhances articles with SEO elements like meta titles and links.
- Verifies quality through a comprehensive checklist.
- Includes measurement and feedback for continuous improvement.

## Usage

To use, simply type `/s` followed by the content idea or draft. The AI will generate:
- An optimized blog article in Markdown format.
- SEO elements such as meta title, description, and slug.
- 2–5 FAQ entries aligned with user intent.
- Internal and external link suggestions.
- A Key Takeaways section and recommended CTA.
- Notes on measurement and iteration.

## Example Prompts

> "/s This article is about the best CRM tools for small businesses."

> "/s How to improve website conversion rates."

## Files (if applicable)

- None

## Notes

The skill emphasizes intent over keywords and structures content for both clarity and SEO performance. It automatically handles objections and integrates a conversion-focused call-to-action.

## Best Practices

1. Focus on the reader's intent and journey stage when drafting content.
2. Use the provided prompts to ensure content aligns with user needs and SEO best practices.
3. Regularly review and iterate on content based on performance metrics and feedback.